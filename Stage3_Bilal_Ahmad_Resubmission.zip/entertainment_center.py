# Stage 3: CREATE A MOVIE WEBSITE

# Importing the class file
import media
import fresh_tomatoes

# Creating instances of Movie class by calling its __init__ function like below
phir_hera_pheri = media.Movie("Phir Hera Pheri",
						"http://www.media.glamsham.com/download/wallpaper/movies/images/p/phirherapheri11_10x7.jpg",
						"https://www.youtube.com/watch?v=1FT6VOrFMLo")

three_idiots = media.Movie("3 Idiots",
					 "http://c.saavncdn.com/246/3-Idiots-2009-500x500.jpg",
					 "https://www.youtube.com/watch?v=xvszmNXdM4w")

omar_series = media.Movie("Omar series",
						 "http://images.alarabiya.net/7c/cc/640x392_96087_227742.jpg",
						 "https://www.youtube.com/watch?v=xMu_654ASDk&list=PLA23D8DF57063041D&index=30")

lagaan =  media.Movie("Lagaan",
					  "http://s1.dmcdn.net/KB0Ta/x240-neQ.jpg",
					  "https://www.youtube.com/watch?v=1rpZxkwDuME")

# creating a list of Movie instances
movies = [phir_hera_pheri, three_idiots, omar_series, lagaan]

# Calling the function from fresh_tomatoes.py which takes a list movie instances to ouput an HTML file, then
# 	opens it in the browser.
fresh_tomatoes.open_movies_page(movies)
