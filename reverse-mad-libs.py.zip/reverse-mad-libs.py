"""
reading a sentence with blanks in it and
then filling in the blanks appropriately

Inputs:
User input to select difficulty leve easy/medium/hard - integer
User input to fill in the first blank - string word


Process:
Initialize three lists with correct answers
Initialize strings with blanks for each level of difficulty

Define three functions;
- selecting difficulty = DONE
- Comparing user entry with the answer
Take user's guess and compare it with answer's index, assign to blanks list index if correct
--> Repeat if incorrect

- Replacing answer with blank and printing it Output


Output:
If Correct answer, Display correct answer in the previous blank and
a new prompt for next blank until level complete.

If incorrect answer, prompt to try again

REMEMBER:
** Include comment for each function to explain what it does

"""

blanks  = ["___1___", "___2___", "___3___", "___4___"]

easy_answers = ["abstract", "programming", "normal", "parameter"]

easy_string = """Thinking about a Python program, a Python interpreter,
and a web browser as different versions of the same thing (a computer program)
shows """ + blanks[0] + """ thinking.
Ambiguity is one difference between """ + blanks[1] + " and " + blanks[2] + """ languages.
The input a procedure takes is called a """ + blanks[3] + "."

medium_string = """When a while loop runs instructions forever, it is a
called an """ + blanks[0] + """ loop. Changing a value of a list after creating it
is called """ + blanks[1] + """. The expression, string.find('something', 4), will give
the first occurrence of 'something' starting from """ + blanks[2] + """ index. Whereas
str.(num) changes the integer type into a """ + blanks[3] + " type."

medium_answers = ["infinite", "mutation", "fourth", "string"]


hard_string = "In Python, functions are procedures refer to " + blanks[0] + """ thing(s). A
 """ + blanks[1] + """ variable is destroyed as soon as the function finishes. When you change an
  """ + blanks[2] + """ variable, you change the pointer to point to a new value; however, with a
  """ + blanks[3] + """ variable, you can change the value that is being pointed to without changing
 the pointer."""

hard_answers = ["same", "local", "immutable", "mutable"]


def difficulty():
	"""
	Asks users for the difficult level and
	returns the corresponding strings and answers as a tuple
	"""
	user_input = raw_input("""Type the number next to the difficulty level:
		\n1: Easy \n2: Medium \n3: Hard \n""")
	if user_input == "1":
		print "Let's start with an easy one :)\n"
		return easy_string, easy_answers
	if user_input == "2":
		print "I like the medium approach ^.^\n"
		return medium_string, medium_answers
	if user_input == "3":
		print "You better be ready for a difficult problem >.<\n"
		return hard_string, hard_answers

def get_blank(word, blanks):
	"""
	Checks if the word passed in has reached the blank space in the sentence
	"""
	for blank in blanks:
		if blank in word:
			return blank
	return None

def check_input(guess, answer):
	"""
	Checks user's answer against the correct answer and re-prompts if incorrect
	"""
	while guess not in answer:
		print "Wrong answer, try again: "
		guess = raw_input("")
	return True


def start_quiz(problem_string, answers, blanks):
	"""
	The main logic behind reverse-madlibs game.
	Splits a string into a list to loop through it.
	Then, user's input is compared against the correct answers.
	Lastly, it puts together a results list to print out the full answer
	"""
	result = []
	index = 0
	print problem_string
	split_string = problem_string.split()
	for word in split_string:
		blank = get_blank(word, blanks)
		if blank:
			user_guess = raw_input("\nWhat should go in blank " + str(index +1) + "? " )
			if check_input(user_guess, answers[index]):
				problem_string = problem_string.replace(blank, user_guess)
				print "\nCorrect!!!\n\n" + problem_string
				index += 1
	#return problem_string

"""
starting the reverse-mad libs game by prompting for the difficult level and
storing answer as a tuple to be passed in later.
"""
(string, answers) = difficulty()

#print "\n" + start_quiz(string, answers, blanks) + "\n"
start_quiz(string, answers, blanks)
print "\nThanks for playing and keep on learning!"










